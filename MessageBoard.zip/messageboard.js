import express from "express";
import exphbs  from "express-handlebars";
import bcrypt from "bcrypt";
import cookieParser from 'cookie-parser';
import {v4 as uuidv4} from "uuid";

const app = express();

import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import { SSL_OP_SSLEAY_080_CLIENT_DH_BUG } from "constants";
import e from "express";

const dbPromise = open({
    filename:'lenderbond.db',
    driver: sqlite3.Database 

});

app.engine("handlebars", exphbs());
app.set("view engine", "handlebars");

app.use(cookieParser())
app.use(express.urlencoded({ extended: false }));
app.use('/static', express.static(__dirname + '/static'));

//Get From Cookie
var userID = 1;
//Get From Cookie

app.post('/newtopic', async(req,res) =>
{
  const db = await dbPromise;
 // var userID = req.cookies.userID;
  var topicText  = req.body.newtopic;
  var topicType  = req.body.TopicSubject;
  var newMessage = req.body.newMessage; 
  var newTopicId;

  await db.run('INSERT INTO messageBoard (subjectTitle,dateCreated,threadTopic) VALUES (?, ?, ?);', topicText, new Date().toISOString(), topicType);
  newTopicId = await db.all("SELECT MBthred_id FROM MBmessages");  
  
  var array = [];
  for(var b = 0; b < newTopicId.length; b++)
  {
  array[b]  = newTopicId[b].MBthred_id;
  }

  var m = Math.max(...array);

  m++;
  await db.run('INSERT INTO MBmessages (MBthred_id,user_id,MessageTimestamp,message) VALUES (?, ?, ?, ?);', m,userID, new Date().toISOString(), newMessage);


      res.redirect("/messagetopic?id="+m); 
});

app.post('/newmessage', async(req,res) =>
{
  const db = await dbPromise;
  var topicID = req.body.topicID;
  var newMessage = req.body.newmessage;

  await db.run('INSERT INTO MBmessages (MBthred_id,user_id,MessageTimestamp,message) VALUES (?, ?, ?, ?);', topicID,userID, new Date().toISOString(), newMessage);
  
  res.redirect("/messagetopic?id="+topicID); 
});


app.get('/messagetopic', async(req,res) =>{

   const db = await dbPromise;
   const allMessages = await db.all("SELECT * FROM MBmessages Where MBthred_id =?",req.query.id);
   const topic = await db.get("SELECT subjectTitle FROM messageBoard WHERE MBthred_id =?", req.query.id);
   var topicID = req.query.id;
   res.render("messagetopic",{allMessages, topic, topicID})

});

app.get("/messageboard",async (req,res) =>
{
  //Temp cookie set
  //res.cookie('userID', 1);
  //Set Cookie Externally in final
  //var userID = req.cookies.userID;

  const db = await dbPromise;
  const allThreads = await db.all("SELECT * FROM messageBoard ORDER BY MBthred_id ASC");
  
  res.render("messageboard",{allThreads});

});

app.get('/',(req,res) =>
{
  res.render("home");
});

const setup = async () => {
    const db = await dbPromise;
    await db.migrate();
  
    app.listen(8080, () => {
      console.log("listening on http://localhost:8080");
    });
  }
  
  setup();