import express from "express";
import exphbs  from "express-handlebars";
import bcrypt from "bcrypt";
import cookieParser from 'cookie-parser';
import {v4 as uuidv4} from "uuid";

const app = express();

import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import { SSL_OP_SSLEAY_080_CLIENT_DH_BUG } from "constants";
import e from "express";

const dbPromise = open({
    filename:'lenderbond.db',
    driver: sqlite3.Database 

});

app.engine("handlebars", exphbs());
app.set("view engine", "handlebars");

app.use(cookieParser())
app.use(express.urlencoded({ extended: false }));
app.use('/static', express.static(__dirname + '/static'));

//Get From Cookie
const userID = 1; //change to test different values for user id 
//Get From Cookie

app.post('/newdirectmessage', async(req,res) =>{
  const db = await dbPromise;
  //var userID = req.cookies.userID;
  var Head_User = userID;
  var usernameText = req.body.SelectedUserID;

  var userId = await db.get('SELECT user_id FROM accountHolder WHERE username =?',usernameText);
  await db.run('INSERT INTO DirectMessages (Head_User,MessageTimestamp,Message,Other_User) VALUES (?, ?, ?, ?);',
  Head_User,new Date().toISOString(),req.body.message,userId.user_id);

      res.redirect("/direct") }

);

app.get("/direct",async (req,res) =>
{
  //Temp cookie set
  //res.cookie('userID', 1);
  //Set Cookie Externally in final
  //var userID = req.cookies.userID;
  
  const db = await dbPromise;
  const messagesAllSent = await db.all("SELECT * FROM DirectMessages WHERE Head_User =?",userID);
  const messagesAllReceived = await db.all("SELECT * FROM DirectMessages WHERE Other_User =?",userID);

  var DM_IDArray = [];
  var Head_UserArray = [];
  var MessageTimestampArray = [];
  var MessageArray = [];
  var Other_UserArray = [];
  var catchMax;
  var k = 0;

  for(var i = 0; i < messagesAllSent.length;i++)
  {
    DM_IDArray[i] = messagesAllSent[i].DM_ID;
    Head_UserArray[i] = messagesAllSent[i].Head_User;
    MessageTimestampArray[i] = messagesAllSent[i].MessageTimestamp;
    MessageArray[i] = messagesAllSent[i].Message;
    Other_UserArray[i] = messagesAllSent[i].Other_User;
    catchMax = i + 1;
  }
  for(var l = catchMax; l < messagesAllSent.length + messagesAllReceived.length; l++)
  {
    DM_IDArray[l] = messagesAllReceived[k].DM_ID;
    Head_UserArray[l] = messagesAllReceived[k].Head_User;
    MessageTimestampArray[l] = messagesAllReceived[k].MessageTimestamp;
    MessageArray[l] = messagesAllReceived[k].Message;
    Other_UserArray[l] = messagesAllReceived[k].Other_User;
    k++
  }

   var uniqueOtherUser = [...new Set(Other_UserArray)];

   uniqueOtherUser = uniqueOtherUser.sort();

    var MessagesSent = await db.all("SELECT Message FROM DirectMessages WHERE Head_User =(?)", userID);
    var MessagesReceived = await db.all("SELECT Message FROM DirectMessages WHERE Other_User =(?)", userID);
    var MessageStack = [];

    var IDsent = await db.all("SELECT Head_User FROM DirectMessages");
    var OtherUserID =  await db.get("SELECT Other_User FROM DirectMessages WHERE Head_User =(?) ORDER BY DM_ID ASC", userID);
    
    var UserIDStack = [];

    for(var a = 0; a < IDsent.length; a++)
    {
        if(IDsent[a].Head_User == userID || IDsent[a].Head_User == OtherUserID.Other_User)
        {
          UserIDStack[a] = IDsent[a].Head_User; 
        }
        else
        {

        }
    }

    var DateArrayUnsorted = [];
    var DateArraySorted = [];

    for(var c = 0; c < MessageTimestampArray.length; c++)
    {
      DateArraySorted[c]   = new Date(MessageTimestampArray[c]);
      DateArrayUnsorted[c] = new Date(MessageTimestampArray[c]); 
       
    }

    DateArraySorted.sort(function(a, b){return a - b});
    var SortedIndex = [];

for(var y = 0;y < DateArrayUnsorted.length; y++)
{
    for(var q = 0; q < DateArraySorted.length; q++)
    {
      if(DateArraySorted[q].toISOString() == DateArrayUnsorted[y].toISOString())
      {
          
          SortedIndex[y] = q;
      }
      else
      {

      }

    }

  }

  var usernameStack = [];
  const usernameReceived = await db.all("SELECT user_id, username FROM accountHolder ORDER BY user_id ASC",);
  
  var l = 0;

    for(var j = 0; j < MessagesSent.length; j++)
    {
        MessageStack[l] = MessagesSent[j].Message;
        l++;
    } 
    
    for(var k = 0; k < MessagesReceived.length; k++)
    {
        MessageStack[l] = messagesAllReceived[k].Message;
        l++;
    }  

    for(var f = 0; f < UserIDStack.length; f++)
    {
      for(var o = 0; o < usernameReceived.length;o++)
      {
          if(usernameReceived[o].user_id == UserIDStack[f])
          {
            usernameStack.push(usernameReceived[o].username);
          }
      }
    }

    var ExportMessages  = [];
    var ExportUserIDs   = [];
    var ExportUserNames = [];

    for(var r = 0;r < MessageStack.length; r++)
    {
       ExportMessages[r] = MessageStack[SortedIndex.indexOf(r)];
    }

    for(var q = 0;q < usernameReceived.length; q++)
    {
      ExportUserIDs[q]  = usernameReceived[q].user_id;
      if(usernameReceived[q].user_id != userID)
      {
        ExportUserNames[q] = usernameReceived[q].username;
      }
    }

  res.render("direct", {ExportMessages,DateArraySorted,usernameStack,UserIDStack,ExportUserIDs,ExportUserNames});
});

app.get('/',(req,res) =>
{
  res.render("home");
});

const setup = async () => {
    const db = await dbPromise;
    await db.migrate();
  
    app.listen(8080, () => {
      console.log("listening on http://localhost:8080");
    });
  }
  
  setup();