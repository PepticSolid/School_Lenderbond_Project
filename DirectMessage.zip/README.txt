This is the raw version of the direct message page. 
It currently has the functionality of loading messages that represent a conversation based on the userID of the user and lets the user send direct messages
which are stored in the database following a post request

main file
directmessage.js

main path
http://localhost:8080/direct


Post request path for creating new message
http://localhost:8080/newdirectmessage


Manage HTML by editing these pages

home.handlebars
main.handlebars
direct.handlebars

Error handling and comments coming soon